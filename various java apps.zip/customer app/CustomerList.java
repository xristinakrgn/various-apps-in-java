/*
	Name: CHRISTINA KARAGIANNI
	Student Number: 3220067
*/
import java.util.Scanner;
public class CustomerList {

    private Customer[] myList;
    private int custNum;

    public CustomerList() {
        myList = new Customer[50];
        custNum = 0;
    }
    public void InsertCustomer() {
        if (custNum < 50) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("\nEnter customer name: ");
            String name = scanner.nextLine();
            System.out.print("Enter customer password: ");
            String password = scanner.nextLine();
            System.out.print("Enter registration day: ");
            int day = scanner.nextInt();
            System.out.print("Enter registration month: ");
            int month = scanner.nextInt();
            System.out.print("Enter registration year: ");
            int year = scanner.nextInt();
            System.out.println(" ");
            scanner.nextLine();
            myList[custNum] = new Customer(name, password, new myDate(day, month, year));
            custNum++;
            System.out.println("Customer added successfully.\n");
        }
        else {
            System.out.println("The list is full. Customer cannot be added.\n");
        }
    }
    public void LookupCustomer(String password) {
        boolean found = false;
        for (int i = 0; i < custNum; i++) {
            if (myList[i].getPassword().equals(password)) {
                System.out.println("\nCustomer name: " + myList[i].getName());
                System.out.println("Registration date: " + myList[i].getRegDate().dayOfDate() + "-"
                                    + myList[i].getRegDate().monthOfDate() + "-"
                                    + myList[i].getRegDate().yearOfDate() + "\n");
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("\nError: customer not found.\n");
        }
    }
    public void DisplayList() {
        for (int i = 0; i < custNum; i++) {
            System.out.println("\nCustomer #" + (i+1) + ":");
            System.out.println("Customer name: " + myList[i].getName());
            System.out.println("Registration date: " + myList[i].getRegDate().dayOfDate() 
                                + "-" + myList[i].getRegDate().monthOfDate() 
                                + "-" + myList[i].getRegDate().yearOfDate());
            System.out.println(" ");
        }
    }
}