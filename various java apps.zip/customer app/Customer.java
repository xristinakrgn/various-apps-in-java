/*
	Name: CHRISTINA KARAGIANNI
	Student Number: 3220067
*/
public class Customer {
    
    private String name;
    private String password;
    private myDate regDate;

    public Customer(String n, String p, myDate rd) {
        name = n;
        password = p;
        regDate = rd;
    }
    public String getName() {
        return name;
    }
    public String getPassword() {
        return password;
    }
    public myDate getRegDate() {
        return regDate;
    }
}