/*
	Name: CHRISTINA KARAGIANNI
	Student Number: 3220067
*/
public class myDate {
    
    private int day;
    private int month;
    private int year;

    public myDate(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }
    public int dayOfDate() {
        return day;
    }
    public int monthOfDate() {
        return month;
    }
    public int yearOfDate() {
        return year;
    }
}