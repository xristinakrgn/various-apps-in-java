/*
	Name: CHRISTINA KARAGIANNI
	Student Number: 3220067
*/
import java.util.Scanner;
public class CustomerApp {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        CustomerList customerlist = new CustomerList();
        boolean n = true;
        while (n == true) {
            System.out.println("Select an option:");
            System.out.println("1. Insert customer");
            System.out.println("2. Search customer");
            System.out.println("3. Display customer list");
            System.out.println("0. Exit");
            System.out.println(" ");
            String answer = in.next();
            in.nextLine();
            if (answer.equals("1")) {
                customerlist.InsertCustomer();
            }
            else if (answer.equals("2")) {
                System.out.print("\nEnter customer password: ");
                String password = in.next();
                customerlist.LookupCustomer(password);
            }
            else if (answer.equals("3")) {
                customerlist.DisplayList();
            }
            else if (answer.equals("0")) {
                System.out.println("\nExiting...");
                n = false;
            }
            else {
                System.out.println("Invalid choice. Try again.");
            }
        }
    }
}