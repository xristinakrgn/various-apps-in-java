/*
	Name: CHRISTINA KARAGIANNI
	Student Number: 3220067
*/
public class Clock {

    protected int hr;
    protected int mn;
    protected int sc;

    public void setHour(int h) {
        hr = h;
    }
    public void setMin(int m) {
        mn = m;
    }
    public void setSec(int s) {
        sc = s;
    }
    public void tick() {
        sc++;
        if (sc >= 60) {
            sc = 0;
            mn++;
            if (mn >= 60) {
                mn = 0;
                hr++;
                if (hr >= 24) {
                    hr = 0;
                }
            }
        }
    }
    
    @Override
    public String toString() {
        return String.format("%02d:%02d:%02d", hr, mn, sc);
    }
}