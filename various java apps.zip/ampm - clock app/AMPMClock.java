/*
	Name: CHRISTINA KARAGIANNI
	Student Number: 3220067
*/
public class AMPMClock extends Clock {

    private boolean amPm;

    public void setAMPM(boolean yes) {
        amPm = yes;
    }

    @Override
    public String toString() {
        if (amPm) {
            int hour = hr % 12;
            if (hour == 0) {
                hour = 12;
            }
            String amPm = (hr < 12) ? "a.m." : "p.m.";
            return String.format("%d:%02d:%02d %s", hour, mn, sc, amPm);
        } 
        else {
            return super.toString();
        }
    }
}
