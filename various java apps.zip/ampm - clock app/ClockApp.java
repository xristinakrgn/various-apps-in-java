/*
	Name: CHRISTINA KARAGIANNI
	Student Number: 3220067
*/
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class ClockApp {

    public static void main(String[] args) throws Exception {
        Clock clock = new Clock();
        
        Scanner in = new Scanner(System.in);
        System.out.print("Enter current hour: ");
        int hour = in.nextInt();
        System.out.print("Enter current minute: ");
        int minute = in.nextInt();
        System.out.print("Enter current second: ");
        int second = in.nextInt();
        
        clock.setHour(hour);
        clock.setMin(minute);
        clock.setSec(second);

        for (int i = 0; i <= 180; i++) {
            System.out.println(clock.toString());
            clock.tick();
            TimeUnit.SECONDS.sleep(1);
        }
        in.close();
    }
}