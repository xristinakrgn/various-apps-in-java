/*
	Name: CHRISTINA KARAGIANNI
	Student Number: 3220067
*/
import java.text.DecimalFormat;
public class VotingApp {

    public static void main(String[] args){
        int[][] voteList = {{182, 41, 202},
                            {145, 85, 325},
                            {195, 15, 115},
                            {110, 24, 407},
                            {255, 11, 357}
        };
        System.out.println("Voting Results:");
        System.out.println("A    B   C");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(voteList[i][j] + "  ");
            }
            System.out.println();
        }
        int[] s = {0, 0, 0};
        for (int j = 0; j < 3; j++) {
            for (int i = 0; i < 5; i++) {
                s[j] = s[j] + voteList[i][j];
            }
        }
        System.out.println("\nThe votes of candidate A are: " + s[0]);
        System.out.println("The votes of candidate B are: " + s[1]);
        System.out.println("The votes of candidate C are: " + s[2]);
        float allVotes = 0;
        for (int i = 0; i < 3; i++) {
            allVotes = allVotes + s[i];
        }
        DecimalFormat df = new DecimalFormat("#.##");
        float prA = (s[0] / allVotes) * 100;
        float prB = (s[1] / allVotes) * 100;
        float prC = (s[2] / allVotes) * 100;
        System.out.println("\nThe percentage of candidate's A votes is: " + df.format(prA) + "%");
        System.out.println("The percentage of candidate's B votes is: " + df.format(prB) + "%");
        System.out.println("The percentage of candidate's C votes is: " + df.format(prC)  + "%");
        float min = 163799;
        String candidateOut = null;
        if (prA > 50) {
            System.out.println("\nA won the election.");
        }
        else if (prB > 50) {
            System.out.println("\nB won the election.");
        }
        else if (prC > 50) {
            System.out.println("\nC won the election.");
        }
        else {
            System.out.println("\nThere will be another round of voting to determine who won the election.");
            if (prA < min) {
                min = prA;
                candidateOut = "A";
            }
            if (prB < min) {
                min = prB;
                candidateOut = "B";
            }
            if (prC < min) {
                min = prC;
                candidateOut = "C";
            }
            if (candidateOut == "A") {
                System.out.println("\nThe candidates that will go head to head at the revision round are B and C.");
                System.out.println("\nThe percentage of candidate's B votes is: " + df.format(prB) + "%");
                System.out.println("The percentage of candidate's C votes is: " + df.format(prC)  + "%");
            }
            else if (candidateOut == "B") {
                System.out.println("\nThe candidates that will go head to head at the revision round are A and C.");
                System.out.println("\nThe percentage of candidate's A votes is: " + df.format(prA) + "%");
                System.out.println("The percentage of candidate's C votes is: " + df.format(prC)  + "%");
            }
            else if (candidateOut == "C") {
                System.out.println("\nThe candidates that will go head to head at the revision round are A and B.");
                System.out.println("\nThe percentage of candidate's A votes is: " + df.format(prA) + "%");
                System.out.println("The percentage of candidate's B votes is: " + df.format(prB)  + "%");
            }
        }
    }
}